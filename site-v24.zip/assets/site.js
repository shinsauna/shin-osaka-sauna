const BASE = "/shin-osaka-sauna/";
const navItems = [
  ["TOP", BASE],
  ["サポート内容", `${BASE}#support`],
  ["私たちについて", `${BASE}#about`],
  ["運営実績", `${BASE}#work`],
  ["よくある質問", `${BASE}#faq`],
  ["会社情報", `${BASE}company/`],
];

function headerMarkup() {
  const links = navItems.map(([label, href]) => `<a href="${href}">${label}</a>`).join("");
  return `<a class="skip-link" href="#main">本文へ移動</a>
  <header class="site-header">
    <div class="header-inner">
      <a class="brand" href="${BASE}" aria-label="真大阪サウナ ホーム"><span class="brand-mark">真</span><span class="brand-name">真大阪サウナ</span></a>
      <nav class="desktop-nav" aria-label="メインナビゲーション">${links}<a class="nav-cta" href="${BASE}contact/">お問い合わせ ↗</a></nav>
      <button class="menu-button" type="button" aria-label="メニューを開く" aria-expanded="false"><span></span></button>
    </div>
    <nav class="mobile-nav" aria-label="モバイルナビゲーション">${links}<a class="nav-cta" href="${BASE}contact/">お問い合わせ</a></nav>
  </header>`;
}

function footerMarkup() {
  const links = navItems.map(([label, href]) => `<a href="${href}">${label}</a>`).join("");
  return `<footer class="site-footer"><div class="container footer-grid"><div>
    <a class="brand" href="${BASE}"><span class="brand-mark">真</span><span class="brand-name">真大阪サウナ</span></a>
    <p class="footer-copy">サウナの開業から、ホテル・旅館・フィットネス施設等への導入、既存施設の経営改善まで。真大阪サウナの運営経験をもとに支援します。</p>
    <p class="footer-address">〒542-0086 大阪市中央区西心斎橋1丁目15-13 アーバンコート心斎橋4F<br><a href="mailto:totonoi.67222@gmail.com">totonoi.67222@gmail.com</a></p>
  </div><nav class="footer-nav" aria-label="フッターナビゲーション">${links}<a href="${BASE}contact/">お問い合わせ</a><a href="${BASE}privacy/">プライバシーポリシー</a></nav></div>
  <div class="container copyright">© 2026 真大阪サウナ</div></footer>
  <div class="mobile-fixed"><a class="button" href="${BASE}contact/">無料相談はこちら →</a></div>`;
}

document.querySelectorAll("[data-site-header]").forEach(el => el.innerHTML = headerMarkup());
document.querySelectorAll("[data-site-footer]").forEach(el => el.innerHTML = footerMarkup());

const menuButton = document.querySelector(".menu-button");
menuButton?.addEventListener("click", () => {
  const open = document.body.classList.toggle("menu-open");
  menuButton.setAttribute("aria-expanded", String(open));
  menuButton.setAttribute("aria-label", open ? "メニューを閉じる" : "メニューを開く");
});
document.querySelectorAll(".mobile-nav a").forEach(a => a.addEventListener("click", () => {
  document.body.classList.remove("menu-open");
  menuButton?.setAttribute("aria-expanded", "false");
}));

const observer = new IntersectionObserver(entries => entries.forEach(entry => {
  if (entry.isIntersecting) { entry.target.classList.add("is-visible"); observer.unobserve(entry.target); }
}), { threshold: .12 });
document.querySelectorAll("[data-reveal]").forEach(el => observer.observe(el));

function renderPerformance(data) {
  const section = document.querySelector("[data-performance-section]");
  const grid = document.querySelector("[data-performance-grid]");
  const svg = document.querySelector("[data-sales-chart]");
  if (!section || !grid || !svg) return;
  const metrics = Array.isArray(data.metrics) ? data.metrics : [];
  const index = Array.isArray(data.salesIndex) ? data.salesIndex : [];
  const validMetric = item => item && typeof item.label === "string" && Number.isFinite(item.value) && typeof item.period === "string" && typeof item.method === "string";
  const validPoint = item => item && typeof item.label === "string" && Number.isFinite(item.value) && item.value >= 0;
  if (metrics.length !== 3 || !metrics.every(validMetric) || index.length < 2 || !index.every(validPoint)) return;

  grid.replaceChildren(...metrics.map((item, i) => {
    const card = document.createElement("article");
    card.className = "performance-card";
    const label = document.createElement("p");
    label.className = "performance-card-label";
    label.textContent = `${String(i + 1).padStart(2, "0")}｜${item.label}`;
    const value = document.createElement("p");
    value.className = "performance-card-value";
    value.textContent = `${item.prefix || ""}${item.value}${item.suffix || "%"}`;
    const meta = document.createElement("p");
    meta.className = "performance-card-meta";
    meta.textContent = `集計期間：${item.period}｜算出方法：${item.method}`;
    card.append(label, value, meta);
    return card;
  }));

  const NS = "http://www.w3.org/2000/svg";
  const W = 760, H = 360, left = 58, right = 22, top = 30, bottom = 54;
  const chartW = W - left - right, chartH = H - top - bottom;
  const values = index.map(point => point.value);
  const rawMin = Math.min(...values), rawMax = Math.max(...values);
  const pad = Math.max((rawMax - rawMin) * .16, 10);
  const min = Math.max(0, Math.floor((rawMin - pad) / 10) * 10);
  const max = Math.ceil((rawMax + pad) / 10) * 10 || 100;
  const x = i => left + (index.length === 1 ? 0 : i * chartW / (index.length - 1));
  const y = value => top + (max - value) * chartH / Math.max(max - min, 1);
  const create = (tag, attrs = {}) => {
    const el = document.createElementNS(NS, tag);
    Object.entries(attrs).forEach(([key, value]) => el.setAttribute(key, String(value)));
    return el;
  };
  svg.setAttribute("viewBox", `0 0 ${W} ${H}`);
  while (svg.lastChild && !["title", "desc"].includes(svg.lastChild.localName)) svg.lastChild.remove();
  for (let i = 0; i <= 4; i += 1) {
    const value = min + (max - min) * i / 4;
    const yy = y(value);
    svg.append(create("line", { x1: left, x2: W - right, y1: yy, y2: yy, class: "chart-grid" }));
    const text = create("text", { x: left - 10, y: yy + 4, "text-anchor": "end", class: "chart-axis-label" });
    text.textContent = String(Math.round(value));
    svg.append(text);
  }
  const coords = index.map((point, i) => [x(i), y(point.value)]);
  const lineD = coords.map(([xx, yy], i) => `${i ? "L" : "M"}${xx},${yy}`).join(" ");
  const areaD = `${lineD} L${coords.at(-1)[0]},${H - bottom} L${coords[0][0]},${H - bottom} Z`;
  svg.append(create("path", { d: areaD, class: "chart-area" }));
  svg.append(create("path", { d: lineD, class: "chart-line" }));
  const labelEvery = Math.max(1, Math.ceil(index.length / 7));
  index.forEach((point, i) => {
    const [xx, yy] = coords[i];
    const circle = create("circle", { cx: xx, cy: yy, r: 6, class: "chart-point", tabindex: 0, "aria-label": `${point.label} 売上指数 ${point.value}` });
    const title = create("title");
    title.textContent = `${point.label}：${point.value}`;
    circle.append(title);
    const value = create("text", { x: xx, y: yy - 13, "text-anchor": "middle", class: "chart-value" });
    value.textContent = String(point.value);
    svg.append(circle, value);
    if (i % labelEvery === 0 || i === index.length - 1) {
      const label = create("text", { x: xx, y: H - 20, "text-anchor": "middle", class: "chart-axis-label" });
      label.textContent = point.label;
      svg.append(label);
    }
  });
  const note = document.querySelector("[data-chart-note]");
  if (note && data.baseLabel) note.textContent = `${data.baseLabel}を100とした売上指数`;
  section.hidden = false;
}

const performanceDataNode = document.getElementById("performance-public-data");
if (performanceDataNode) {
  try { renderPerformance(JSON.parse(performanceDataNode.textContent)); } catch (_) { /* 検証済みデータがない場合は非公開 */ }
}

const form = document.querySelector("[data-contact-form]");
if (form) {
  const typeMap = {
    opening: "サウナ新規開業について",
    installation: "サウナ導入について",
    management: "サウナ経営改善について"
  };
  const requestedType = new URLSearchParams(location.search).get("type");
  if (requestedType && typeMap[requestedType] && form.elements.type) {
    form.elements.type.value = typeMap[requestedType];
  }
  const endpoint = "https://script.google.com/macros/s/AKfycbyA2bUJ83cgcJLxzAymxVYhMX9chgvDcsswZNMkBXHEKivY4nopRFiefJcLnnT2MK1S/exec";
  form.addEventListener("submit", async event => {
    event.preventDefault();
    const status = form.querySelector(".form-status");
    const button = form.querySelector("button[type=submit]");
    if (form.website?.value) return;
    button.disabled = true;
    button.textContent = "送信中…";
    status.textContent = "";
    try {
      const body = new URLSearchParams();
      new FormData(form).forEach((value, key) => body.append(key, String(value)));
      await fetch(endpoint, { method: "POST", mode: "no-cors", body });
      form.innerHTML = `<div class="form-success"><p class="eyebrow">Thank you</p><h2 class="section-title">送信が完了しました</h2><p class="section-copy">内容を確認のうえ、担当者よりご連絡します。</p></div>`;
    } catch (error) {
      status.textContent = "送信できませんでした。時間をおいて、もう一度お試しください。";
      button.disabled = false;
      button.textContent = "相談内容を送信する →";
    }
  });
}
