const BASE = "/shin-osaka-sauna/";
const navItems = [
  ["TOP", BASE],
  ["サポート内容", `${BASE}#support`],
  ["私たちについて", `${BASE}#about`],
  ["運営実績", `${BASE}#work`],
  ["よくある質問", `${BASE}#faq`],
  ["会社情報", `${BASE}company/`],
];

function headerMarkup() {
  const links = navItems.map(([label, href]) => `<a href="${href}">${label}</a>`).join("");
  return `<a class="skip-link" href="#main">本文へ移動</a>
  <header class="site-header">
    <div class="header-inner">
      <a class="brand" href="${BASE}" aria-label="真大阪サウナ ホーム"><span class="brand-mark">真</span><span class="brand-name">真大阪サウナ</span></a>
      <nav class="desktop-nav" aria-label="メインナビゲーション">${links}<a class="nav-cta" href="${BASE}contact/">お問い合わせ ↗</a></nav>
      <button class="menu-button" type="button" aria-label="メニューを開く" aria-expanded="false"><span></span></button>
    </div>
    <nav class="mobile-nav" aria-label="モバイルナビゲーション">${links}<a class="nav-cta" href="${BASE}contact/">お問い合わせ</a></nav>
  </header>`;
}

function footerMarkup() {
  const links = navItems.map(([label, href]) => `<a href="${href}">${label}</a>`).join("");
  return `<footer class="site-footer"><div class="container footer-grid"><div>
    <a class="brand" href="${BASE}"><span class="brand-mark">真</span><span class="brand-name">真大阪サウナ</span></a>
    <p class="footer-copy">サウナの開業から、ホテル・旅館・フィットネス施設等への導入、既存施設の経営改善まで。真大阪サウナの運営経験をもとに支援します。</p>
    <p class="footer-address">〒542-0086 大阪市中央区西心斎橋1丁目15-13 アーバンコート心斎橋4F<br><a href="mailto:totonoi.67222@gmail.com">totonoi.67222@gmail.com</a></p>
  </div><nav class="footer-nav" aria-label="フッターナビゲーション">${links}<a href="${BASE}contact/">お問い合わせ</a><a href="${BASE}privacy/">プライバシーポリシー</a></nav></div>
  <div class="container copyright">© 2026 真大阪サウナ</div></footer>
  <div class="mobile-fixed"><a class="button" href="${BASE}contact/">無料相談はこちら →</a></div>`;
}

document.querySelectorAll("[data-site-header]").forEach(el => el.innerHTML = headerMarkup());
document.querySelectorAll("[data-site-footer]").forEach(el => el.innerHTML = footerMarkup());

const menuButton = document.querySelector(".menu-button");
menuButton?.addEventListener("click", () => {
  const open = document.body.classList.toggle("menu-open");
  menuButton.setAttribute("aria-expanded", String(open));
  menuButton.setAttribute("aria-label", open ? "メニューを閉じる" : "メニューを開く");
});
document.querySelectorAll(".mobile-nav a").forEach(a => a.addEventListener("click", () => {
  document.body.classList.remove("menu-open");
  menuButton?.setAttribute("aria-expanded", "false");
}));

const observer = new IntersectionObserver(entries => entries.forEach(entry => {
  if (entry.isIntersecting) { entry.target.classList.add("is-visible"); observer.unobserve(entry.target); }
}), { threshold: .12 });
document.querySelectorAll("[data-reveal]").forEach(el => observer.observe(el));

const form = document.querySelector("[data-contact-form]");
if (form) {
  const typeMap = {
    opening: "サウナ新規開業について",
    installation: "サウナ導入について",
    management: "サウナ経営改善について"
  };
  const requestedType = new URLSearchParams(location.search).get("type");
  if (requestedType && typeMap[requestedType] && form.elements.type) {
    form.elements.type.value = typeMap[requestedType];
  }
  const endpoint = "https://script.google.com/macros/s/AKfycbyA2bUJ83cgcJLxzAymxVYhMX9chgvDcsswZNMkBXHEKivY4nopRFiefJcLnnT2MK1S/exec";
  form.addEventListener("submit", async event => {
    event.preventDefault();
    const status = form.querySelector(".form-status");
    const button = form.querySelector("button[type=submit]");
    if (form.website?.value) return;
    button.disabled = true;
    button.textContent = "送信中…";
    status.textContent = "";
    try {
      const body = new URLSearchParams();
      new FormData(form).forEach((value, key) => body.append(key, String(value)));
      await fetch(endpoint, { method: "POST", mode: "no-cors", body });
      form.innerHTML = `<div class="form-success"><p class="eyebrow">Thank you</p><h2 class="section-title">送信が完了しました</h2><p class="section-copy">内容を確認のうえ、担当者よりご連絡します。</p></div>`;
    } catch (error) {
      status.textContent = "送信できませんでした。時間をおいて、もう一度お試しください。";
      button.disabled = false;
      button.textContent = "相談内容を送信する →";
    }
  });
}
